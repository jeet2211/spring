package com.microservices.bookingservice.ServiceImpl;

import com.microservices.bookingservice.DTO.RestaurantDTO;
import com.microservices.bookingservice.enums.ReservationStatus;
import com.microservices.bookingservice.model.Reservation;
import com.microservices.bookingservice.model.Restaurant;
import com.microservices.bookingservice.repository.ReservationRepository;
import com.microservices.bookingservice.repository.RestaurantRepository;
import com.microservices.bookingservice.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RestaurantServiceImpl implements RestaurantService {

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    @Override
    public List<Restaurant> getAllRestaurants(String city, String restaurantName) {
        // Implement the logic to fetch restaurants based on city and name
        // You can use the restaurantRepository for database interactions
        // Return a list of restaurants
        return restaurantRepository.findByLocationAndNameContaining(city, restaurantName);
    }

    @Override
    public Restaurant getRestaurantById(Long restaurantId) {
        // Implement the logic to fetch a restaurant by ID
        // You can use the restaurantRepository for database interactions
        // Return the restaurant
        return restaurantRepository.findById(restaurantId)
                .orElse(null);
    }

    @Override
    public Page<Reservation> getReservationRequests(Long restaurantId, ReservationStatus status, Pageable pageable) {
        // Implement the logic to fetch reservation requests for a restaurant
        // You can use the reservationRepository for database interactions
        // Return a Page of Reservation entities
        pageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by("reservationTime").descending());
        return reservationRepository.findByRestaurantRestaurantIdAndStatus(restaurantId, status, pageable);
    }

    @Override
    public void confirmOrRejectReservation(Long reservationId, ReservationStatus status) {
        // Implement the logic to confirm or reject a reservation
        // You can use the reservationRepository for database interactions
        // Update the status of the reservation
        // Additional logic for table allocation can be added here
        reservationRepository.findById(reservationId).ifPresent(reservation -> {
            reservation.setStatus(status);
            reservationRepository.save(reservation);
        });
    }

    @Override
    public Restaurant registerRestaurant(RestaurantDTO restaurantDTO) {
        // Implement the logic to register a new restaurant
        // You can use the restaurantRepository for database interactions
        // Convert the RestaurantDTO to a Restaurant entity and save it
        Restaurant restaurant = new Restaurant();
        restaurant.setName(restaurantDTO.getName());
        restaurant.setCuisines(restaurantDTO.getCuisines());
        restaurant.setLocation(restaurantDTO.getLocation());
        restaurant.setWorkingDays(restaurantDTO.getWorkingDays());
        restaurant.setWorkingHours(restaurantDTO.getWorkingHours());
        restaurant.setTimeSlotInterval(restaurantDTO.getTimeSlotInterval());
        restaurant.setTableType(restaurantDTO.getTableType());
        restaurant.setNumberOfTables(restaurantDTO.getNumberOfTables());
        restaurant.setCapacity(restaurantDTO.getCapacity());

        return restaurantRepository.save(restaurant);
    }

    // Additional methods for restaurant operations can be added here

    // Logout method can be added here if needed
}
