package com.microservices.bookingservice.DTO;

import lombok.Data;

@Data
public class RestaurantDTO {
    private String name;
    private String cuisines;
    private String location;
    private String workingDays;
    private String workingHours;
    private int timeSlotInterval;
    private String tableType;
    private int numberOfTables;
    private int capacity;
}
