package com.microservices.bookingservice.controller;

import com.microservices.bookingservice.DTO.RestaurantDTO;
import com.microservices.bookingservice.enums.ReservationStatus;
import com.microservices.bookingservice.model.Reservation;
import com.microservices.bookingservice.model.Restaurant;
import com.microservices.bookingservice.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/restaurants")
public class RestaurantController {

    @Autowired
    private RestaurantService restaurantService;

    @GetMapping("/getAll")
    public ResponseEntity<List<Restaurant>> getAllRestaurants(@RequestParam(required = false) String city,
                                                              @RequestParam(required = false) String restaurantName) {
        List<Restaurant> restaurants = restaurantService.getAllRestaurants(city, restaurantName);
        return ResponseEntity.ok(restaurants);
    }

    @GetMapping("/{restaurantId}")
    public ResponseEntity<Restaurant> getRestaurantById(@PathVariable Long restaurantId) {
        Restaurant restaurant = restaurantService.getRestaurantById(restaurantId);
        return ResponseEntity.ok(restaurant);
    }

    @GetMapping("/{restaurantId}/reservations")
    public ResponseEntity<Page<Reservation>> getReservationRequests(@PathVariable Long restaurantId,
                                                                    @RequestParam ReservationStatus status,
                                                                    Pageable pageable) {
        Page<Reservation> reservations = restaurantService.getReservationRequests(restaurantId, status, pageable);
        return ResponseEntity.ok(reservations);
    }

    @PutMapping("/{restaurantId}/confirm-reject/{reservationId}")
    public ResponseEntity<?> confirmOrRejectReservation(@PathVariable Long restaurantId,
                                                        @PathVariable Long reservationId,
                                                        @RequestParam ReservationStatus status) {
        restaurantService.confirmOrRejectReservation(reservationId, status);
        return ResponseEntity.ok("Reservation status updated successfully");
    }

    @PostMapping("/register")
    public ResponseEntity<Restaurant> registerRestaurant(@RequestBody RestaurantDTO restaurantDTO) {
        Restaurant registeredRestaurant = restaurantService.registerRestaurant(restaurantDTO);
        return ResponseEntity.ok(registeredRestaurant);
    }

    // Additional methods for restaurant operations can be added here
}
