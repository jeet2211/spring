package com.microservices.bookingservice.service;

import com.microservices.bookingservice.DTO.ReservationDTO;
import com.microservices.bookingservice.enums.ReservationStatus;
import com.microservices.bookingservice.model.Reservation;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface ReservationService {
    List<Reservation> getUserReservations(Long userId);
    List<Reservation> getManagerReservationRequests(Long restaurantId);
    Reservation bookTable(ReservationDTO reservationDTO);
    void cancelReservation(Long reservationId);
    void confirmOrRejectReservation(Long reservationId, ReservationStatus status);
    // ... other methods

}
