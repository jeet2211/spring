package com.microservices.bookingservice.Exceptions;

public class UsernameNotFoundException extends Throwable {
    public UsernameNotFoundException(String message) {
        super(message);
    }
}