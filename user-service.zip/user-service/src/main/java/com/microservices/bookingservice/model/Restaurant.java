package com.microservices.bookingservice.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import jakarta.persistence.*;

import java.util.List;

@Entity
@Data
@Table(name = "Restaurant_Table")
public class Restaurant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long restaurantId;

    @NotBlank(message = "Restaurant name is required")
    private String name;

    private String cuisines;
    private String location;
    private String workingDays;
    private String workingHours;
    private int timeSlotInterval;
    private String tableType;
    private int numberOfTables;
    private int capacity;

    @OneToMany(mappedBy = "restaurant")
    private List<Reservation> reservations;
    // ... other fields, getters, setters
}
