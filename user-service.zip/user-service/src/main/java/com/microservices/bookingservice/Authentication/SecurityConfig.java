//package com.microservices.bookingservice.Authentication;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//
//@Configuration
//@EnableWebSecurity
//public class SecurityConfig {
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder();
//    }
//
//    @Bean
//    public UserDetails user() {
//        return User.withUsername("user")
//                .password(passwordEncoder().encode("a2f81a2d-22b3-4db2-8567-0fcc28e872ff"))
//                .roles("USER")
//                .build();
//    }
//
//    @Bean
//    public UserDetails admin() {
//        return User.withUsername("admin")
//                .password(passwordEncoder().encode("admin-password"))
//                .roles("ADMIN")
//                .build();
//    }
//
//    @Bean
//    public UserDetails manager() {
//        return User.withUsername("manager")
//                .password(passwordEncoder().encode("manager-password"))
//                .roles("MANAGER")
//                .build();
//    }
//
//    @Bean
//    public UserDetails superuser() {
//        return User.withUsername("superuser")
//                .password(passwordEncoder().encode("superuser-password"))
//                .roles("ADMIN", "MANAGER")
//                .build();
//    }
//}
