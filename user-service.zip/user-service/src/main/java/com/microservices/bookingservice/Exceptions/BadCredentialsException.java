package com.microservices.bookingservice.Exceptions;

public class BadCredentialsException extends Throwable {
    public BadCredentialsException(String message) {
        super(message);
    }
}
