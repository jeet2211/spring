package com.microservices.bookingservice.service;

import com.microservices.bookingservice.DTO.RestaurantDTO;
import com.microservices.bookingservice.enums.ReservationStatus;
import com.microservices.bookingservice.model.Reservation;
import com.microservices.bookingservice.model.Restaurant;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface RestaurantService {

    // Customer Operations

    List<Restaurant> getAllRestaurants(String city, String restaurantName);

    Restaurant getRestaurantById(Long restaurantId);

    // Manager Operations

    Page<Reservation> getReservationRequests(Long restaurantId, ReservationStatus status, Pageable pageable);

    void confirmOrRejectReservation(Long reservationId, ReservationStatus status);

    Restaurant registerRestaurant(RestaurantDTO restaurantDTO);

    // Additional methods for restaurant operations can be added here

    // Logout method can be added here if needed
}
