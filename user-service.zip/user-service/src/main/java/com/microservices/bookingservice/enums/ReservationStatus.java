package com.microservices.bookingservice.enums;

public enum ReservationStatus {
    PENDING, CONFIRMED, REJECTED
}
