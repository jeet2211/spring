package com.microservices.bookingservice.ServiceImpl;

import com.microservices.bookingservice.DTO.ReservationDTO;
import com.microservices.bookingservice.Exceptions.NotFoundException;
import com.microservices.bookingservice.enums.ReservationStatus;
import com.microservices.bookingservice.model.Reservation;
import com.microservices.bookingservice.model.Restaurant;
import com.microservices.bookingservice.model.User;
import com.microservices.bookingservice.repository.ReservationRepository;
import com.microservices.bookingservice.repository.RestaurantRepository;
import com.microservices.bookingservice.repository.UserRepository;
import com.microservices.bookingservice.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReservationServiceImpl implements ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Override
    public List<Reservation> getUserReservations(Long userId) {
        return reservationRepository.findByUserUserId(userId);
    }

    @Override
    public List<Reservation> getManagerReservationRequests(Long restaurantId) {
        return reservationRepository.findByRestaurantRestaurantIdAndStatus(restaurantId, ReservationStatus.PENDING);
    }

    @Override
    public Reservation bookTable(ReservationDTO reservationDTO) {
        // Validate if the user and restaurant exist
        User user = userRepository.findById(reservationDTO.getUserId())
                .orElseThrow(() -> new NotFoundException("User not found"));

        Restaurant restaurant = restaurantRepository.findById(reservationDTO.getRestaurantId())
                .orElseThrow(() -> new NotFoundException("Restaurant not found"));

        // Additional validation logic can be added here

        // Create a new reservation
        Reservation reservation = new Reservation();
        reservation.setUser(user);
        reservation.setRestaurant(restaurant);
        reservation.setReservationTime(reservationDTO.getReservationTime());
        reservation.setReservationDate(reservationDTO.getReservationDate());
        reservation.setNumberOfPeople(reservationDTO.getNumberOfPeople());
        reservation.setStatus(ReservationStatus.PENDING);

        // Save the reservation to the database
        return reservationRepository.save(reservation);
    }

    @Override
    public void cancelReservation(Long reservationId) {
        Optional<Reservation> existingReservation = reservationRepository.findById(reservationId);
        if (existingReservation.isPresent()) {
            reservationRepository.deleteById(reservationId);
        } else {
            throw new NotFoundException("Reservation not found");
        }
    }

    @Override
    public void confirmOrRejectReservation(Long reservationId, ReservationStatus status) {
        Optional<Reservation> existingReservation = reservationRepository.findById(reservationId);
        if (existingReservation.isPresent()) {
            Reservation reservation = existingReservation.get();
            reservation.setStatus(status);
            reservationRepository.save(reservation);
        } else {
            throw new NotFoundException("Reservation not found");
        }
    }

    // Additional methods for reservation operations can be added here
}
