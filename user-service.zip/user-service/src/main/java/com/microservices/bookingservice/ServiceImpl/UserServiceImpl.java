package com.microservices.bookingservice.ServiceImpl;

import com.microservices.bookingservice.DTO.UserRegistrationDto;
import com.microservices.bookingservice.Exceptions.BadCredentialsException;
import com.microservices.bookingservice.Exceptions.UsernameNotFoundException;
import com.microservices.bookingservice.enums.Role;
import com.microservices.bookingservice.model.User;
import com.microservices.bookingservice.repository.UserRepository;
import com.microservices.bookingservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

//    @Autowired
//    private PasswordEncoder passwordEncoder;
    @Override
    public User registerUser(UserRegistrationDto registrationDto) throws BadCredentialsException {
        if (userRepository.existsByEmail(registrationDto.getEmail())) {
            throw new BadCredentialsException("User with this email already exists");
        }
        User user = new User();
        user.setFullName(registrationDto.getFullName());
        user.setEmail(registrationDto.getEmail());
//        user.setPassword(passwordEncoder.encode(registrationDto.getPassword()));
        user.setPassword(registrationDto.getPassword());
        user.setPhoneNumber(registrationDto.getPhoneNumber());
        user.setRole(Role.CUSTOMER); // Set default role as customer

        // Save the user to the database
        return userRepository.save(user);

    }

    @Override
    public String login(String email, String password) {
        // Perform authentication logic here (e.g., use Spring Security authentication manager)
        // For simplicity, let's assume the authentication is successful and return a token
        // In a real-world scenario, use Spring Security or another authentication mechanism

        // Placeholder: Return a dummy token for simplicity
        return "dummy_token";
    }

    @Override
    public User findByEmail(String email) throws UsernameNotFoundException {
        return (User) userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
    }

    @Override
    public ResponseEntity<List<User>> getUsers() {
        try {
            List<User> users = userRepository.findAll();
            return new ResponseEntity<>(users, HttpStatus.OK);
        } catch (Exception exception) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<?> getUserById(Long userId) {
        try {
            Optional<User> user = userRepository.findById(userId);
            return user.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                    .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
        } catch (Exception exception) {
            return new ResponseEntity<>("Failed to retrieve user.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> createUser(User newUser) {
        try {
            Optional<User> existingUser = userRepository.getByEmail(newUser.getEmail());
            if (existingUser.isPresent()) {
                return new ResponseEntity<>("User with this email already present", HttpStatus.BAD_REQUEST);
            }

            User user = userRepository.save(newUser);
            return new ResponseEntity<>(user, HttpStatus.CREATED);

        } catch (Exception exception) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<?> updateUser(Long userId, User newUser) {
        try {
            Optional<User> existingUser = userRepository.findById(userId);
            if (existingUser.isPresent()) {
                User updatedUser = existingUser.get();
                updatedUser.setFullName(newUser.getFullName());
                // Update other fields as needed

                User updatedUserObj = userRepository.save(updatedUser);
                return new ResponseEntity<>(updatedUserObj, HttpStatus.OK);
            }
            return new ResponseEntity<>("User not found with this id", HttpStatus.NOT_FOUND);

        } catch (Exception exception) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<?> deleteUser(Long userId) {
        try {
            Optional<User> existingUser = userRepository.findById(userId);
            if (existingUser.isPresent()) {
                userRepository.deleteById(userId);
                return new ResponseEntity<>("User deleted successfully", HttpStatus.OK);
            }
            return new ResponseEntity<>("User not found with this id", HttpStatus.NOT_FOUND);

        } catch (Exception exception) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
