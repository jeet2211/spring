//package com.microservices.bookingservice.controller;
//
//import com.microservices.bookingservice.DTO.ReservationDTO;
//import com.microservices.bookingservice.enums.ReservationStatus;
//import com.microservices.bookingservice.model.Reservation;
//import com.microservices.bookingservice.service.ReservationService;
//import jakarta.validation.Valid;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
////import org.springframework.security.core.Authentication;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/reservations")
//public class ReservationController {
//
//    @Autowired
//    private ReservationService reservationService;
//
//    @GetMapping("/user")
//    public ResponseEntity<List<Reservation>> getUserReservations(Authentication authentication) {
//        Long userId = getUserIdFromAuthentication(authentication);
//        List<Reservation> userReservations = reservationService.getUserReservations(userId);
//        return ResponseEntity.ok(userReservations);
//    }
//
//    @GetMapping("/manager")
//    public ResponseEntity<List<Reservation>> getManagerReservationRequests(Authentication authentication) {
//        Long restaurantId = getRestaurantIdFromAuthentication(authentication);
//        List<Reservation> managerReservationRequests = reservationService.getManagerReservationRequests(restaurantId);
//        return ResponseEntity.ok(managerReservationRequests);
//    }
//
//    @PostMapping("/book")
//    public ResponseEntity<Reservation> bookTable(@RequestBody @Valid ReservationDTO reservationRequestDto, Authentication authentication) {
//        Long userId = getUserIdFromAuthentication(authentication);
//
//        ReservationDTO reservationDTO = new ReservationDTO();
//        reservationDTO.setUserId(userId);
//        reservationDTO.setRestaurantId(reservationRequestDto.getRestaurantId());
//        reservationDTO.setReservationTime(reservationRequestDto.getReservationTime());
//        reservationDTO.setReservationDate(reservationRequestDto.getReservationDate());
//        reservationDTO.setNumberOfPeople(reservationRequestDto.getNumberOfPeople());
//
//        Reservation bookedReservation = reservationService.bookTable(reservationDTO);
//
//        return ResponseEntity.ok(bookedReservation);
//    }
//
//
//    @DeleteMapping("/cancel/{reservationId}")
//    public ResponseEntity<?> cancelReservation(@PathVariable Long reservationId) {
//        reservationService.cancelReservation(reservationId);
//        return ResponseEntity.ok("Reservation canceled successfully");
//    }
//
//    @PutMapping("/confirm-reject/{reservationId}")
//    public ResponseEntity<?> confirmOrRejectReservation(@PathVariable Long reservationId, @RequestParam ReservationStatus status) {
//        reservationService.confirmOrRejectReservation(reservationId, status);
//        return ResponseEntity.ok("Reservation status updated successfully");
//    }
//
//    // Helper method to extract the user ID from authentication
//    private Long getUserIdFromAuthentication(Authentication authentication) {
//        // Extract user ID from authentication details
//        // Implement as needed based on your authentication setup
//        return 1L; // Placeholder value, replace with actual logic
//    }
//
//    // Helper method to extract the restaurant ID from authentication
//    private Long getRestaurantIdFromAuthentication(Authentication authentication) {
//        // Extract restaurant ID from authentication details
//        // Implement as needed based on your authentication setup
//        return 1L; // Placeholder value, replace with actual logic
//    }
//}
