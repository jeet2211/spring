package com.microservices.bookingservice.model;

import com.microservices.bookingservice.enums.ReservationStatus;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
@Data
@Entity
@Table(name = "Reservation_Table")
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reservationId;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "restaurant_id")
    private Restaurant restaurant;

    private LocalDateTime reservationTime;
    private LocalDate reservationDate;
    private int numberOfPeople;

    @Enumerated(EnumType.STRING)
    private ReservationStatus status;

    // ... other fields, getters, setters
}
