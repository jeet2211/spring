package com.microservices.bookingservice.enums;

public enum Role {
    CUSTOMER,
    MANAGER
    // Add more roles as needed
}
