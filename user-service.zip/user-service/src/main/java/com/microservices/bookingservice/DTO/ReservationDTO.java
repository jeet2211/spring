package com.microservices.bookingservice.DTO;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
@Data
public class ReservationDTO {
    private Long userId;
    private Long restaurantId;
    private LocalDateTime reservationTime;
    private LocalDate reservationDate;
    private int numberOfPeople;
    // ... getters, setters
}
