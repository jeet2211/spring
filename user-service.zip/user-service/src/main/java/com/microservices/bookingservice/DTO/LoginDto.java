package com.microservices.bookingservice.DTO;

import lombok.Data;

@Data
public class LoginDto {
    private String email;
    private String password;
}
