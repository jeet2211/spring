
package com.microservices.bookingservice.repository;

import com.microservices.bookingservice.model.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RestaurantRepository extends JpaRepository<Restaurant, Long> {
    // Additional query methods if needed
    List<Restaurant> findByLocation(String location);

//    @Query("SELECT r FROM Restaurant r ORDER BY SIZE(r.reservations) DESC, r.workingDays")
//    List<Restaurant> findByOrderByNumberOfBookingsDescAndWorkingDays();
//
//    List<Restaurant> findByOrderByNumberOfBookingsDesc();
//    List<Restaurant> findByOrderByNumberOfBookingsDescAndWorkingDays(String workingDays);
//    List<Restaurant> findByNameContainingIgnoreCaseAndLocation(String name, String location);
//
    List<Restaurant> findByLocationAndNameContaining(String city, String restaurantName);
}
