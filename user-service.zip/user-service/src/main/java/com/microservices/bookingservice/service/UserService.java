package com.microservices.bookingservice.service;

import com.microservices.bookingservice.DTO.UserRegistrationDto;
import com.microservices.bookingservice.Exceptions.BadCredentialsException;
import com.microservices.bookingservice.Exceptions.UsernameNotFoundException;
import com.microservices.bookingservice.model.User;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserService {
    User registerUser(UserRegistrationDto registrationDto) throws BadCredentialsException;
    String login(String email, String password);
    User findByEmail(String email) throws UsernameNotFoundException;

    ResponseEntity<List<User>> getUsers();

    ResponseEntity<?> getUserById(Long id);

    ResponseEntity<?> updateUser(Long id, User newUser);

    ResponseEntity<?> deleteUser(Long id);
}
